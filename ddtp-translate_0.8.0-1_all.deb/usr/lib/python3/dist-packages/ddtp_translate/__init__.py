"""DDTP Translate — Translate Debian package descriptions."""

__version__ = "0.8.0"
